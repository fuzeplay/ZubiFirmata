# ZubiFirmata

A fork of the Arduino Firmata firmware to work with the Fuze Zubi Flyer board
